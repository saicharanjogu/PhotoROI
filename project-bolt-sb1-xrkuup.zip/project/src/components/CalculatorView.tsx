import React, { useState } from 'react';
import { UserData } from '../App';
import { CostAnalysis } from './calculator/CostAnalysis';
import { TimelineComparison } from './calculator/TimelineComparison';
import { AutomationROI } from './calculator/AutomationROI';
import { RevenueProjection } from './calculator/RevenueProjection';

interface CalculatorViewProps {
  userData: UserData;
}

export function CalculatorView({ userData }: CalculatorViewProps) {
  const [activeTab, setActiveTab] = useState('costs');

  const tabs = [
    { id: 'costs', name: 'Cost Analysis', icon: '💰' },
    { id: 'timeline', name: 'Timeline Comparison', icon: '⏱️' },
    { id: 'automation', name: 'Automation ROI', icon: '🤖' },
    { id: 'revenue', name: 'Revenue Projection', icon: '📈' },
  ];

  return (
    <div className="bg-white rounded-xl shadow-lg">
      <div className="border-b border-gray-200">
        <div className="flex overflow-x-auto">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`
                flex-1 py-4 px-4 text-center border-b-2 font-medium text-sm
                ${
                  activeTab === tab.id
                    ? 'border-indigo-500 text-indigo-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }
              `}
            >
              <span className="mr-2">{tab.icon}</span>
              {tab.name}
            </button>
          ))}
        </div>
      </div>

      <div className="p-6">
        <div className="mb-6">
          <h2 className="text-2xl font-bold text-gray-900">
            Welcome, {userData.name}!
          </h2>
          <p className="text-gray-600">
            Let's optimize your photography business at {userData.companyName}
          </p>
        </div>

        {activeTab === 'costs' && <CostAnalysis />}
        {activeTab === 'timeline' && <TimelineComparison />}
        {activeTab === 'automation' && <AutomationROI />}
        {activeTab === 'revenue' && <RevenueProjection />}
      </div>
    </div>
  );
}