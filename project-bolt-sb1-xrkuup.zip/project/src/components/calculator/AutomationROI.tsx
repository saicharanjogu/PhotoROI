import React, { useState } from 'react';

export function AutomationROI() {
  const [automation, setAutomation] = useState({
    currentTime: 6,
    solutionCost: 2000,
    timeSavings: 70,
    qualityTime: 1,
    eventsPerMonth: 8,
    hourlyRate: 25,
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setAutomation((prev) => ({
      ...prev,
      [name]: parseFloat(value) || 0,
    }));
  };

  // Calculations
  const currentMonthlyTime = automation.currentTime * automation.eventsPerMonth;
  const automatedMonthlyTime = (automation.currentTime * (100 - automation.timeSavings) / 100) * automation.eventsPerMonth;
  const monthlySavedHours = currentMonthlyTime - automatedMonthlyTime;
  const monthlySavings = monthlySavedHours * automation.hourlyRate;
  const breakEvenMonths = Math.ceil(automation.solutionCost / monthlySavings);
  const yearlyROI = ((monthlySavings * 12 - automation.solutionCost) / automation.solutionCost * 100);

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Current Processing Hours per Event
            </label>
            <input
              type="number"
              name="currentTime"
              value={automation.currentTime}
              onChange={handleInputChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Automation Solution Cost ($)
            </label>
            <input
              type="number"
              name="solutionCost"
              value={automation.solutionCost}
              onChange={handleInputChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Expected Time Savings (%)
            </label>
            <input
              type="number"
              name="timeSavings"
              value={automation.timeSavings}
              onChange={handleInputChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            />
          </div>
        </div>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Quality Control Hours per Event
            </label>
            <input
              type="number"
              name="qualityTime"
              value={automation.qualityTime}
              onChange={handleInputChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Events per Month
            </label>
            <input
              type="number"
              name="eventsPerMonth"
              value={automation.eventsPerMonth}
              onChange={handleInputChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Hourly Rate ($)
            </label>
            <input
              type="number"
              name="hourlyRate"
              value={automation.hourlyRate}
              onChange={handleInputChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            />
          </div>
        </div>
      </div>

      <div className="bg-gray-50 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">ROI Analysis</h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-white p-4 rounded-lg shadow-sm">
            <div className="text-sm text-gray-500">Monthly Time Savings</div>
            <div className="text-2xl font-bold text-gray-900">{monthlySavedHours.toFixed(1)} hours</div>
          </div>
          <div className="bg-white p-4 rounded-lg shadow-sm">
            <div className="text-sm text-gray-500">Monthly Cost Savings</div>
            <div className="text-2xl font-bold text-gray-900">${monthlySavings.toFixed(0)}</div>
          </div>
          <div className="bg-white p-4 rounded-lg shadow-sm">
            <div className="text-sm text-gray-500">Break-even Period</div>
            <div className="text-2xl font-bold text-indigo-600">{breakEvenMonths} months</div>
          </div>
          <div className="bg-white p-4 rounded-lg shadow-sm">
            <div className="text-sm text-gray-500">First Year ROI</div>
            <div className="text-2xl font-bold text-indigo-600">{yearlyROI.toFixed(0)}%</div>
          </div>
        </div>
      </div>

      <div className="bg-indigo-50 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Impact Analysis</h3>
        <div className="space-y-4">
          <div>
            <div className="text-sm font-medium text-gray-700 mb-2">Time Efficiency</div>
            <div className="w-full bg-gray-200 rounded-full h-2.5">
              <div
                className="bg-indigo-600 h-2.5 rounded-full"
                style={{ width: `${automation.timeSavings}%` }}
              ></div>
            </div>
            <div className="text-sm text-gray-500 mt-1">
              {automation.timeSavings}% reduction in processing time
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}