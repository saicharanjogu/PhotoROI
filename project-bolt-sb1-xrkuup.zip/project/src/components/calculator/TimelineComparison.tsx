import React, { useState } from 'react';

export function TimelineComparison() {
  const [baseDelivery, setBaseDelivery] = useState({
    days: 14,
    price: 1500,
    satisfaction: 85,
  });

  const rushOptions = [
    { days: 1, premium: 75, satisfaction: 98 },
    { days: 2, premium: 50, satisfaction: 95 },
    { days: 3, premium: 35, satisfaction: 92 },
  ];

  return (
    <div className="space-y-8">
      <div className="bg-gray-50 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Standard Delivery</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Current Timeline (days)
            </label>
            <input
              type="number"
              value={baseDelivery.days}
              onChange={(e) => setBaseDelivery({ ...baseDelivery, days: parseInt(e.target.value) || 0 })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Base Price ($)
            </label>
            <input
              type="number"
              value={baseDelivery.price}
              onChange={(e) => setBaseDelivery({ ...baseDelivery, price: parseInt(e.target.value) || 0 })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Client Satisfaction (%)
            </label>
            <input
              type="number"
              value={baseDelivery.satisfaction}
              onChange={(e) => setBaseDelivery({ ...baseDelivery, satisfaction: parseInt(e.target.value) || 0 })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            />
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-gray-900">Rush Delivery Options</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {rushOptions.map((option) => (
            <div key={option.days} className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
              <div className="text-lg font-semibold text-gray-900 mb-2">
                {option.days} Day Delivery
              </div>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-500">Premium</span>
                  <span className="font-medium text-gray-900">+{option.premium}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Price</span>
                  <span className="font-medium text-gray-900">
                    ${(baseDelivery.price * (1 + option.premium / 100)).toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Satisfaction</span>
                  <span className="font-medium text-indigo-600">{option.satisfaction}%</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-indigo-50 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Recommendations</h3>
        <ul className="space-y-2 text-gray-700">
          <li>• Offering rush delivery options can increase revenue by up to 75%</li>
          <li>• Client satisfaction increases significantly with faster delivery</li>
          <li>• Consider automation tools to make faster delivery times sustainable</li>
        </ul>
      </div>
    </div>
  );
}