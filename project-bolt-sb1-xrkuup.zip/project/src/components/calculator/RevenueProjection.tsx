import React, { useState } from 'react';

export function RevenueProjection() {
  const [projection, setProjection] = useState({
    currentRevenue: 12000,
    growthRate: 15,
    retentionRate: 85,
    priceIncrease: 10,
    additionalEvents: 2,
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setProjection((prev) => ({
      ...prev,
      [name]: parseFloat(value) || 0,
    }));
  };

  // Calculate different growth scenarios
  const conservative = projection.currentRevenue * (1 + projection.growthRate / 200);
  const moderate = projection.currentRevenue * (1 + projection.growthRate / 100);
  const aggressive = projection.currentRevenue * (1 + projection.growthRate / 50);

  const scenarios = [
    {
      name: 'Conservative',
      revenue: conservative,
      description: 'Minimal changes to current operations',
      color: 'bg-blue-100',
      textColor: 'text-blue-800',
    },
    {
      name: 'Moderate',
      revenue: moderate,
      description: 'Balanced optimization approach',
      color: 'bg-indigo-100',
      textColor: 'text-indigo-800',
    },
    {
      name: 'Aggressive',
      revenue: aggressive,
      description: 'Maximum optimization implementation',
      color: 'bg-purple-100',
      textColor: 'text-purple-800',
    },
  ];

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Current Monthly Revenue ($)
            </label>
            <input
              type="number"
              name="currentRevenue"
              value={projection.currentRevenue}
              onChange={handleInputChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Expected Growth Rate (%)
            </label>
            <input
              type="number"
              name="growthRate"
              value={projection.growthRate}
              onChange={handleInputChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Client Retention Rate (%)
            </label>
            <input
              type="number"
              name="retentionRate"
              value={projection.retentionRate}
              onChange={handleInputChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            />
          </div>
        </div>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Price Increase (%)
            </label>
            <input
              type="number"
              name="priceIncrease"
              value={projection.priceIncrease}
              onChange={handleInputChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Additional Monthly Events
            </label>
            <input
              type="number"
              name="additionalEvents"
              value={projection.additionalEvents}
              onChange={handleInputChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            />
          </div>
        </div>
      </div>

      <div className="space-y-6">
        <h3 className="text-lg font-semibold text-gray-900">Growth Scenarios</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {scenarios.map((scenario) => (
            <div
              key={scenario.name}
              className={`rounded-lg p-6 ${scenario.color}`}
            >
              <div className={`text-lg font-semibold ${scenario.textColor} mb-2`}>
                {scenario.name}
              </div>
              <div className="text-2xl font-bold text-gray-900 mb-2">
                ${scenario.revenue.toLocaleString()}
              </div>
              <div className="text-sm text-gray-600">{scenario.description}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-gray-50 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Key Growth Factors</h3>
        <div className="space-y-4">
          <div>
            <div className="flex justify-between mb-1">
              <span className="text-sm font-medium text-gray-700">Client Retention Impact</span>
              <span className="text-sm text-gray-600">
                ${(projection.currentRevenue * (projection.retentionRate / 100)).toLocaleString()}
              </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2.5">
              <div
                className="bg-indigo-600 h-2.5 rounded-full"
                style={{ width: `${projection.retentionRate}%` }}
              ></div>
            </div>
          </div>
          <div>
            <div className="flex justify-between mb-1">
              <span className="text-sm font-medium text-gray-700">Price Increase Impact</span>
              <span className="text-sm text-gray-600">
                ${(projection.currentRevenue * (projection.priceIncrease / 100)).toLocaleString()}
              </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2.5">
              <div
                className="bg-green-600 h-2.5 rounded-full"
                style={{ width: `${projection.priceIncrease * 2}%` }}
              ></div>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-indigo-50 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Recommendations</h3>
        <ul className="space-y-2 text-gray-700">
          <li>• Focus on client retention to maintain stable revenue growth</li>
          <li>• Gradually implement price increases based on improved service quality</li>
          <li>• Expand capacity to handle additional events through automation</li>
          <li>• Monitor customer satisfaction to support higher pricing</li>
        </ul>
      </div>
    </div>
  );
}