import React, { useState } from 'react';

export function CostAnalysis() {
  const [costs, setCosts] = useState({
    baseRate: 1500,
    eventsPerMonth: 8,
    deliveryDays: 14,
    processingHours: 6,
    staffRate: 25,
    storageCosts: 100,
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setCosts((prev) => ({
      ...prev,
      [name]: parseFloat(value) || 0,
    }));
  };

  const monthlyRevenue = costs.baseRate * costs.eventsPerMonth;
  const monthlyLaborCost = costs.processingHours * costs.staffRate * costs.eventsPerMonth;
  const totalMonthlyCosts = monthlyLaborCost + costs.storageCosts;
  const monthlyProfit = monthlyRevenue - totalMonthlyCosts;

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Base Package Rate ($)
            </label>
            <input
              type="number"
              name="baseRate"
              value={costs.baseRate}
              onChange={handleInputChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Events per Month
            </label>
            <input
              type="number"
              name="eventsPerMonth"
              value={costs.eventsPerMonth}
              onChange={handleInputChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Current Delivery Timeline (days)
            </label>
            <input
              type="number"
              name="deliveryDays"
              value={costs.deliveryDays}
              onChange={handleInputChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            />
          </div>
        </div>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Processing Hours per Event
            </label>
            <input
              type="number"
              name="processingHours"
              value={costs.processingHours}
              onChange={handleInputChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Staff Hourly Rate ($)
            </label>
            <input
              type="number"
              name="staffRate"
              value={costs.staffRate}
              onChange={handleInputChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Monthly Storage/Software Costs ($)
            </label>
            <input
              type="number"
              name="storageCosts"
              value={costs.storageCosts}
              onChange={handleInputChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            />
          </div>
        </div>
      </div>

      <div className="bg-gray-50 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Monthly Summary</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white p-4 rounded-lg shadow-sm">
            <div className="text-sm text-gray-500">Revenue</div>
            <div className="text-2xl font-bold text-gray-900">${monthlyRevenue.toLocaleString()}</div>
          </div>
          <div className="bg-white p-4 rounded-lg shadow-sm">
            <div className="text-sm text-gray-500">Costs</div>
            <div className="text-2xl font-bold text-gray-900">${totalMonthlyCosts.toLocaleString()}</div>
          </div>
          <div className="bg-white p-4 rounded-lg shadow-sm">
            <div className="text-sm text-gray-500">Profit</div>
            <div className="text-2xl font-bold text-indigo-600">${monthlyProfit.toLocaleString()}</div>
          </div>
        </div>
      </div>
    </div>
  );
}