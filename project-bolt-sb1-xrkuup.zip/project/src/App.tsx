import React from 'react';
import { Calculator, Camera } from 'lucide-react';
import { LeadCaptureForm } from './components/LeadCaptureForm';
import { useState } from 'react';
import { CalculatorView } from './components/CalculatorView';

export type UserData = {
  name: string;
  email: string;
  phone: string;
  companyName: string;
};

function App() {
  const [userData, setUserData] = useState<UserData | null>(null);

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-indigo-50">
      <nav className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Camera className="h-8 w-8 text-indigo-600" />
              <span className="text-xl font-semibold text-gray-900">PhotoROI</span>
            </div>
            <div className="flex items-center space-x-2">
              <Calculator className="h-6 w-6 text-indigo-600" />
              <span className="text-sm font-medium text-gray-600">Budget Optimizer</span>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {!userData ? (
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h1 className="text-4xl font-bold text-gray-900 mb-4">
                Optimize Your Event Photography Business
              </h1>
              <p className="text-lg text-gray-600">
                Discover how to increase your revenue, reduce costs, and streamline your workflow
                with our advanced ROI calculator.
              </p>
            </div>
            <div className="grid md:grid-cols-2 gap-8 mb-12">
              <div className="bg-white rounded-xl shadow-sm p-6">
                <div className="flex items-center justify-center h-12 w-12 rounded-md bg-indigo-500 text-white mb-4">
                  <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                  </svg>
                </div>
                <h3 className="text-lg font-semibold mb-2">Revenue Optimization</h3>
                <p className="text-gray-600">Analyze pricing strategies and identify opportunities for growth</p>
              </div>
              <div className="bg-white rounded-xl shadow-sm p-6">
                <div className="flex items-center justify-center h-12 w-12 rounded-md bg-indigo-500 text-white mb-4">
                  <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <h3 className="text-lg font-semibold mb-2">Time Management</h3>
                <p className="text-gray-600">Optimize delivery timelines and workflow efficiency</p>
              </div>
            </div>
            <LeadCaptureForm onSubmit={setUserData} />
          </div>
        ) : (
          <CalculatorView userData={userData} />
        )}
      </main>

      <footer className="bg-white mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <p className="text-center text-gray-500 text-sm">
            © {new Date().getFullYear()} PhotoROI. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;